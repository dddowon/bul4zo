package com.example.jol_1;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.jol_1.R;

public class DealActivity4 extends AppCompatActivity implements View.OnClickListener {
    EditText edit_deal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deal4);

        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        findViewById(R.id.btn_deal).setOnClickListener(this);
        edit_deal = findViewById(R.id.edit_deal);
    }

    @Override
    public void onClick(View view) {
        if (edit_deal.length() == 0)
            Toast.makeText(this, "거래할 전력량을 기입해주세요.", Toast.LENGTH_SHORT).show();
        else {
            Toast.makeText(this, "거래가 완료되었습니다.", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, MainhomeActivity.class);
            startActivity(intent);
        }
    }
}