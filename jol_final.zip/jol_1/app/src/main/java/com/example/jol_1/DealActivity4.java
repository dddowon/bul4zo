package com.example.jol_1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.example.jol_1.R;

public class DealActivity4 extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deal4);

        findViewById(R.id.btn_deal).setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

    }
}