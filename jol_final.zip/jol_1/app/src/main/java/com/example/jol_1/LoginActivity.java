package com.example.jol_1;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {



    Button mbtn_url;
    EditText userid, passwd;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();


        mbtn_url = findViewById(R.id.btn_url);
        findViewById(R.id.btn_login).setOnClickListener(this);

        userid = findViewById(R.id.userid);
        passwd = findViewById(R.id.passwd);

        mbtn_url.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent urlintent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.naver.com"));
                startActivity(urlintent);
            }
        });




    }


    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btn_login:
                String str_userid = userid.getText().toString();
                String str_passwd = passwd.getText().toString();

                if(str_userid.length()<4){
                    Toast.makeText(this, "아이디는 4자 이상이여야 합니다\n 아이디를 다시 입력하세요.", Toast.LENGTH_SHORT).show();
                }
                else if(str_passwd.length()<8){
                    Toast.makeText(this, "비밀번호는 8자 이상이여야 합니다\n 비밀번호를 다시 입력하세요.", Toast.LENGTH_SHORT).show();
                }
                else if(str_userid.equals("user1") && str_passwd.equals("12345678")){
                    Toast.makeText(this, "환영합니다" + str_userid +"님", Toast.LENGTH_SHORT).show();
                    Intent intent_login = new Intent(LoginActivity.this, MainhomeActivity.class);
                    startActivity(intent_login);
                }
                else
                    Toast.makeText(this, "아이디와 패스워드가 일치하지 않습니다.", Toast.LENGTH_SHORT).show();


        }
    }
}