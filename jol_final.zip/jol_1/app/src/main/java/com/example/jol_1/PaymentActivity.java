package com.example.jol_1;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class PaymentActivity extends AppCompatActivity implements TextView.OnEditorActionListener {
    EditText int_num;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        int_num = findViewById(R.id.input);

        int_num.setOnEditorActionListener(this);

    }


    @Override
    public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
        if(textView.getId()==R.id.input && i ==EditorInfo.IME_ACTION_DONE){
            String str_num = int_num.getText().toString();
            if(str_num.equals("1234")){
                Toast.makeText(this, "결제가 완료되었습니다.", Toast.LENGTH_SHORT).show();
                Intent pay_intent = new Intent(PaymentActivity.this, MainhomeActivity.class);
                startActivity(pay_intent);
            }
            else
                Toast.makeText(this, "비밀번호가 맞지 않습니다.", Toast.LENGTH_SHORT).show();
        }

        return false;
    }
}