package com.example.jol_1;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;


public class DealActivity extends AppCompatActivity implements View.OnClickListener {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deal);

        findViewById(R.id.btn_upload).setOnClickListener(this);
        findViewById(R.id.btn_deal).setOnClickListener(this);
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btn_upload:
                Intent upload_intent= new Intent(DealActivity.this, DealActivity2.class);
                startActivity(upload_intent);
                break;
            case R.id.btn_deal:
                Toast.makeText(this, "먼저 판매자를 등록해주세요.", Toast.LENGTH_SHORT).show();
                break;
        }
    }
}