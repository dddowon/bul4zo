package com.example.jol_1;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class DealActivity2 extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deal2);

        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        findViewById(R.id.btn1).setOnClickListener(this);
        findViewById(R.id.btn2).setOnClickListener(this);
        findViewById(R.id.btn3).setOnClickListener(this);
        findViewById(R.id.btn4).setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btn1:
                Toast.makeText(this, "등록이 완료되었습니다.", Toast.LENGTH_SHORT).show();
                Intent btn1_intent = new Intent(DealActivity2.this, DealActivity3.class);
                startActivity(btn1_intent);
                break;
            case R.id.btn2:
                Toast.makeText(this, "등록이 완료되었습니다.", Toast.LENGTH_SHORT).show();
                Intent btn2_intent = new Intent(DealActivity2.this, DealActivity4.class);
                startActivity(btn2_intent);
                break;
            case R.id.btn3:
                Toast.makeText(this, "등록이 완료되었습니다.", Toast.LENGTH_SHORT).show();
                Intent btn3_intent = new Intent(DealActivity2.this, DealActivity5.class);
                startActivity(btn3_intent);
                break;
            case R.id.btn4:
                Toast.makeText(this, "등록이 완료되었습니다.", Toast.LENGTH_SHORT).show();
                Intent btn4_intent = new Intent(DealActivity2.this, DealActivity6.class);
                startActivity(btn4_intent);
                break;
        }
    }
}