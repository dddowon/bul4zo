package com.example.jol_1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class TransactionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transaction);
    }
}