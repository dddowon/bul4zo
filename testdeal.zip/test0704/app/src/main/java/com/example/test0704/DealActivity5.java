package com.example.test0704;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

public class DealActivity5 extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deal5);

        findViewById(R.id.btn_deal).setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {

    }
}