package com.example.test1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.SearchView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    TextView sell_id, sell_name, sell_electric;
    TextView buy_id, buy_name, buy_electric;

    String val_sell_id, val_sell_name;
    int val_sell_electric;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.btn_upload).setOnClickListener(this);

        sell_id = findViewById(R.id.sell_id);
        sell_name = findViewById(R.id.sell_name);
        sell_electric = findViewById(R.id.sell_electric);


    }

    void  textTotal(){
        sell_id.setText("id : " + val_sell_id);
        sell_name.setText("name : " + val_sell_name);
        sell_electric.setText("보유전력 : " +val_sell_electric+"mAp");
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btn_upload:
                Intent upload_intent= new Intent(MainActivity.this, MainActivity2.class);
                startActivity(upload_intent);
        }
    }
}